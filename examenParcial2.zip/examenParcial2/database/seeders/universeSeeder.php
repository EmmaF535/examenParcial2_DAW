<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class universeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $universo = new universes;
        $universo->id=1;
        $universo->universe_name="DC Comics";
        $universo->save();

        $universo = new universes;
        $universo->id=1;
        $universo->universe_name="Marvel";
        $universo->save();

        $universo = new universes;
        $universo->id=1;
        $universo->universe_name="Netflix";
        $universo->save();

    }
}