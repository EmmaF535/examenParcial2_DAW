<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class logosController extends Controller
{
    //
}
