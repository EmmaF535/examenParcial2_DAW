<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::resource('/superheroes', superheroesController::class);
Route::resource('/universes', universesController::class);
Route::resource('/logos', logosController::class);
